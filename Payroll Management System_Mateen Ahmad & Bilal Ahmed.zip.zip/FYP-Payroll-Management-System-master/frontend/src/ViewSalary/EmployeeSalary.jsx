import React from 'react'

const EmployeeSalary = () => {
  return (
    <div>EmployeeSalary</div>
  )
}

export default EmployeeSalary